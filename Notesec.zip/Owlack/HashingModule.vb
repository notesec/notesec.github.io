﻿Imports System.Text
Imports System.Security.Cryptography

Module HashingModule
    Public isregistered As Boolean = False
    ' Fungsi membuat "serial number" dari teks
    Public Function ComputeSerialHash(ByVal plainText As String, Optional ByVal groupLength As Integer = 4, Optional ByVal groups As Integer = 4) As String
        ' 1. Buat hash SHA256 dari teks
        Dim bytes As Byte() = Encoding.UTF8.GetBytes(plainText)
        Dim sha As SHA256 = SHA256.Create()
        Dim hashBytes As Byte() = sha.ComputeHash(bytes)

        ' 2. Ambil sebagian byte untuk serial
        Dim serialBytes(hashBytes.Length - 1) As Byte
        Array.Copy(hashBytes, serialBytes, hashBytes.Length)

        ' 3. Konversi ke karakter A-Z, 0-9
        Dim chars As String = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        Dim sb As New StringBuilder()

        For i As Integer = 0 To (groupLength * groups) - 1
            ' Gunakan modulus untuk memilih karakter
            sb.Append(chars(serialBytes(i Mod serialBytes.Length) Mod chars.Length))
        Next

        ' 4. Tambahkan tanda "-" setiap groupLength karakter
        For i As Integer = groups - 1 To 1 Step -1
            sb.Insert(i * groupLength, "-")
        Next

        Return sb.ToString()
    End Function

    ' Fungsi verifikasi serial hash
    Public Function VerifySerialHash(ByVal plainText As String, ByVal serial As String, Optional ByVal groupLength As Integer = 4, Optional ByVal groups As Integer = 4) As Boolean
        Dim generatedSerial As String = ComputeSerialHash(plainText, groupLength, groups)
        Return String.Compare(generatedSerial, serial, True) = 0
    End Function


End Module
