﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following 
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("Notesec")> 
<Assembly: AssemblyDescription("Secure Notes. Fully Offline. Absolute Privacy.")> 
<Assembly: AssemblyCompany("Notesec Labs")> 
<Assembly: AssemblyProduct("Notesec")> 
<Assembly: AssemblyCopyright("© 2015 - 2026 Notesec Labs. All Rights Reserved.")> 
<Assembly: AssemblyTrademark("")> 

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("8fb90d60-bf41-49a8-810c-c0321a0e831c")> 

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version 
'      Build Number
'      Revision
'
' You can specify all the values or you can default the Build and Revision Numbers 
' by using the '*' as shown below:
' <Assembly: AssemblyVersion("1.0.*")> 

<Assembly: AssemblyVersion("4.2.1.0")> 
<Assembly: AssemblyFileVersion("4.2.1.0")> 
