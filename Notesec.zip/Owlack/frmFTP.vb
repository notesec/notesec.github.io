﻿Imports System.IO
Imports System.Threading

Public Class frmFTP

    Private Sub frmFTP_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        txtLocalFile.Clear()
        txtLog.Clear()
    End Sub

    Private Sub frmFTP_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        cmbProtocol.Items.AddRange(New Object() {"FTP", "FTPS", "SFTP"})
        cmbProtocol.SelectedIndex = 0

        cmbSSL.Items.AddRange(New Object() {"None", "Explicit TLS", "Insecure"})
        cmbSSL.SelectedIndex = 0
        If String.IsNullOrEmpty(txtPort.Text) Then
            txtPort.Text = "21"
        End If

        loadftp()
    End Sub

    Private Sub btnBrowse_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnBrowse.Click
        ofd.Filter = "Notesec Files (*.ns)|*.ns"
        ofd.DefaultExt = "ns"
        If ofd.ShowDialog() = DialogResult.OK Then
            txtLocalFile.Text = ofd.FileName
        End If
    End Sub
    Sub savesettings()
        My.Settings.FTPhost = txtHost.Text
        My.Settings.FTPport = txtPort.Text
        My.Settings.FTPuser = txtUsername.Text
        My.Settings.FTPpass = txtPassword.Text
        My.Settings.Save()
    End Sub
    Sub loadftp()
        txtHost.Text = My.Settings.FTPhost
        txtPort.Text = My.Settings.FTPport
        txtUsername.Text = My.Settings.FTPuser
        txtPassword.Text = My.Settings.FTPpass
    End Sub
    Sub deactive()
        txtHost.Enabled = False
        txtPort.Enabled = False
        txtUsername.Enabled = False
        txtPassword.Enabled = False
        cmbProtocol.Enabled = False
        cmbSSL.Enabled = False
        txtLocalFile.Enabled = False
        txtRemotePath.Enabled = False
        btnBrowse.Enabled = False
        btnUpload.Enabled = False
    End Sub
    Sub active()
        txtHost.Enabled = True
        txtPort.Enabled = True
        txtUsername.Enabled = True
        txtPassword.Enabled = True
        cmbProtocol.Enabled = True
        cmbSSL.Enabled = True
        txtLocalFile.Enabled = True
        txtRemotePath.Enabled = True
        btnBrowse.Enabled = True
        btnUpload.Enabled = True
    End Sub
    Private Sub btnUpload_Click(ByVal sender As Object, ByVal e As EventArgs) Handles btnUpload.Click
        txtLog.Clear()
        btnUpload.Enabled = False

        ' Ambil data UI di UI thread
        Dim uiData As New UploadContext()
        uiData.Host = txtHost.Text.Trim()
        uiData.Port = Integer.Parse(txtPort.Text)
        uiData.Username = txtUsername.Text.Trim()
        uiData.Password = txtPassword.Text
        uiData.LocalFile = txtLocalFile.Text.Trim()
        uiData.RemotePath = txtRemotePath.Text.Trim()
        uiData.ProtocolText = cmbProtocol.Text
        uiData.SSLText = cmbSSL.Text
        deactive()
        savesettings()
        Dim t As New Thread(AddressOf StartUpload)
        t.IsBackground = True
        t.Start(uiData)
    End Sub

    Private Sub StartUpload(ByVal dataObj As Object)

        Dim data As UploadContext = CType(dataObj, UploadContext)

        Dim protocol As FtpUploader.ProtocolType
        Select Case data.ProtocolText
            Case "FTPS"
                protocol = FtpUploader.ProtocolType.FTPS
            Case "SFTP"
                protocol = FtpUploader.ProtocolType.SFTP
            Case Else
                protocol = FtpUploader.ProtocolType.FTP
        End Select

        Dim ssl As FtpUploader.SSLModeType
        Select Case data.SSLText
            Case "Explicit TLS"
                ssl = FtpUploader.SSLModeType.ExplicitTLS
            Case "Insecure"
                ssl = FtpUploader.SSLModeType.Insecure
            Case Else
                ssl = FtpUploader.SSLModeType.None
        End Select

        Log("Starting upload to " & txtHost.Text & "...")

        Dim result As String = FtpUploader.UploadFile( _
            Path.Combine("C:\Windows", "curl.exe"), _
            data.LocalFile, _
            data.Host, _
            data.Port, _
            data.Username, _
            data.Password, _
            data.RemotePath, _
            protocol, _
            ssl _
        )

        Log(result)

        Me.Invoke(New MethodInvoker(Sub()
                                        btnUpload.Enabled = True
                                        active()
                                    End Sub))
    End Sub


    Private Sub Log(ByVal msg As String)
        Me.Invoke(New MethodInvoker(Sub()
                                        txtLog.AppendText("[" & Now.ToString("HH:mm:ss") & "] " & msg & vbCrLf)
                                    End Sub))
    End Sub

    Private Sub txtLog_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtLog.Click
        Me.ActiveControl = Nothing
    End Sub

    Private Sub txtLog_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtLog.TextChanged
        Me.ActiveControl = Nothing
    End Sub
End Class
Public Class UploadContext
    Public Host As String
    Public Port As Integer
    Public Username As String
    Public Password As String
    Public LocalFile As String
    Public RemotePath As String
    Public ProtocolText As String
    Public SSLText As String
End Class
