﻿Imports System.IO
Imports System.Drawing.Printing
Imports System.Text
Imports System.Threading
Imports System.Text.RegularExpressions
Imports System.Windows.Forms
Imports System.Security.Cryptography
Imports System.Runtime.InteropServices
Public Class Form1
    Public userpassword As String
    Public defaultpassword As String
    Private Const WDA_NONE As UInteger = 0
    Private Const WDA_MONITOR As UInteger = 1
    Private blinkCount As Integer = 0
    Private blinkTarget As RichTextBox = Nothing
    Private isBlinking As Boolean = False
    ' Import fungsi WinAPI
    <DllImport("user32.dll")>
    Private Shared Function SetWindowDisplayAffinity(ByVal hWnd As IntPtr, ByVal dwAffinity As UInteger) As Boolean
    End Function
    Private regpath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "data.reg")
    Private Class SaveParams
        Public Tab As TabPage
        Public FilePath As String
    End Class

    Private Class OpenParams
        Public FilePath As String
    End Class

    Private currentZoom As Single = 1.0F
    Private WithEvents printDoc As New Printing.PrintDocument()
    Private pageSetup As New PageSetupDialog()
    Private tabFilePaths As New Dictionary(Of TabPage, String)
    ' Menyimpan status perubahan
    Private tabModified As New Dictionary(Of TabPage, Boolean)
    Private lastFindText As String = ""
    Private lastFindIndex As Integer = -1
    Private tabEncodings As New Dictionary(Of TabPage, Encoding)
    Private isLoadingFile As Boolean = False
    Private Function GetEncoding(ByVal encType As TextEncodingType) As Encoding
        Select Case encType
            Case TextEncodingType.ANSI
                Return Encoding.Default
            Case TextEncodingType.UTF8
                Return New UTF8Encoding(False)
            Case TextEncodingType.UTF8_BOM
                Return New UTF8Encoding(True)
            Case TextEncodingType.Unicode
                Return Encoding.Unicode
            Case Else
                Return Encoding.UTF8
        End Select
    End Function
    Private Sub UpdateFormTitle()
        Dim tab As TabPage = TabControl1.SelectedTab
        If tab Is Nothing Then
            Me.Text = "Notesec"
            lbtabname.Text = "Tab - None"
            Return
        End If

        Dim name As String = tab.Text
        ' Hilangkan tanda * jika ada
        If name.StartsWith("*") Then
            name = name.Substring(1)
        End If

        Me.Text = name & " - Notesec"
        lbtabname.Text = "Tab - " & name
    End Sub

    Private Function SelectEncoding(ByRef encType As TextEncodingType) As Boolean
        Dim msg As String = _
            "Select Encoding:" & vbCrLf & vbCrLf &
            "Yes   = UTF-8" & vbCrLf &
            "No    = ANSI" & vbCrLf &
            "Cancel= Unicode"

        Dim res As DialogResult = MessageBox.Show(msg, "Encoding", MessageBoxButtons.YesNoCancel)

        If res = DialogResult.Yes Then
            encType = TextEncodingType.UTF8
        ElseIf res = DialogResult.No Then
            encType = TextEncodingType.ANSI
        ElseIf res = DialogResult.Cancel Then
            encType = TextEncodingType.Unicode
        Else
            Return False
        End If

        Return True
    End Function

    Public Enum TextEncodingType
        ANSI
        UTF8
        UTF8_BOM
        Unicode
    End Enum
    Private Sub UpdateStatusBar()
        Dim rtb As RichTextBox = GetActiveRTB()
        If rtb Is Nothing Then Exit Sub

        ' ===== Line & Column =====
        Dim index As Integer = rtb.SelectionStart
        Dim line As Integer = rtb.GetLineFromCharIndex(index)
        Dim col As Integer = index - rtb.GetFirstCharIndexFromLine(line)

        lbstatus1.Text = "Line " & (line + 1) & ", Col " & (col + 1)

        ' ===== Zoom =====
        lbstatus2.Text = CInt(currentZoom * 100) & "%"

        ' ===== Line Ending =====
        If rtb.Text.Contains(vbCrLf) Then
            lbstatus3.Text = "Windows (CRLF)"
        ElseIf rtb.Text.Contains(vbLf) Then
            lbstatus3.Text = "Unix (LF)"
        ElseIf rtb.Text.Contains(vbCr) Then
            lbstatus3.Text = "Mac (CR)"
        Else
            lbstatus3.Text = "Windows (CRLF)"
        End If

        ' ===== Encoding =====
        Dim enc As Encoding = Encoding.UTF8
        If tabEncodings.ContainsKey(TabControl1.SelectedTab) Then
            enc = tabEncodings(TabControl1.SelectedTab)
        End If

        If enc Is Encoding.UTF8 Then
            lbstatus4.Text = "UTF-8"
        ElseIf enc Is Encoding.Unicode Then
            lbstatus4.Text = "Unicode (UTF-16 LE)"
        ElseIf enc Is Encoding.BigEndianUnicode Then
            lbstatus4.Text = "Unicode (UTF-16 BE)"
        Else
            lbstatus4.Text = "ANSI"
        End If
    End Sub

    Private Sub UpdateMenuState()
        Dim hasTab As Boolean = (TabControl1.TabPages.Count > 0)
        Dim rtb As RichTextBox = GetActiveRTB()

        Dim hasText As Boolean = (rtb IsNot Nothing AndAlso rtb.TextLength > 0)
        Dim hasSelection As Boolean = (rtb IsNot Nothing AndAlso rtb.SelectionLength > 0)
        Dim canUndo As Boolean = (rtb IsNot Nothing AndAlso rtb.CanUndo)
        Dim isModified As Boolean = False

        If hasTab AndAlso tabModified.ContainsKey(TabControl1.SelectedTab) Then
            isModified = tabModified(TabControl1.SelectedTab)
        End If

        ' ===== FILE =====
        SaveToolStripMenuItem.Enabled = hasTab AndAlso isModified
        btnsave.Enabled = hasTab AndAlso isModified
        SaveAsToolStripMenuItem.Enabled = hasTab
        btnsaveas.Enabled = hasTab
        OpenToolStripMenuItem.Enabled = True
        btnopen.Enabled = True
        NewToolStripMenuItem.Enabled = True
        btnnew.Enabled = True
        PrintToolStripMenuItem.Enabled = hasText
        btnprint.Enabled = hasText
        PageSetupToolStripMenuItem.Enabled = hasTab
        btnpagestup.Enabled = hasTab

        ' ===== EDIT =====
        UndoToolStripMenuItem.Enabled = canUndo
        CutToolStripMenuItem.Enabled = hasSelection
        CopyToolStripMenuItem.Enabled = hasSelection
        DeleteToolStripMenuItem.Enabled = hasSelection
        PasteToolStripMenuItem.Enabled = Clipboard.ContainsText()
        SelectAllToolStripMenuItem.Enabled = hasText

        FindToolStripMenuItem.Enabled = hasText
        ReplaceToolStripMenuItem.Enabled = hasText

        ' ===== VIEW =====
        ZoomInToolStripMenuItem.Enabled = hasTab
        ZoomOutToolStripMenuItem.Enabled = hasTab
        RestoreDefaultZoomToolStripMenuItem.Enabled = hasTab

        WordWrapToolStripMenuItem.Enabled = hasTab
        WordWrapToolStripMenuItem.Checked = If(rtb IsNot Nothing, rtb.WordWrap, False)

        FontToolStripMenuItem.Enabled = hasTab

        StatusBarToolStripMenuItem.Enabled = True
    End Sub

    Private Function GetActiveRTB() As RichTextBox
        If TabControl1.SelectedTab Is Nothing Then Return Nothing
        Return CType(TabControl1.SelectedTab.Controls(0), RichTextBox)
    End Function
    Private Sub AddNewTab(Optional ByVal title As String = "Untitled")
        Dim rtb As New RichTextBox()
        rtb.Dock = DockStyle.Fill
        rtb.BorderStyle = BorderStyle.None
        If isregistered Then
        Else
            rtb.MaxLength = 500
        End If
        Dim ukuranBaru As Single = 10 ' misal 14pt
        rtb.Font = New Font(rtb.Font.FontFamily, ukuranBaru, rtb.Font.Style)
        rtb.Multiline = True
        rtb.ScrollBars = RichTextBoxScrollBars.Both
        rtb.WordWrap = True
        AddHandler rtb.TextChanged, AddressOf RichTextBox_TextChanged
        AddHandler rtb.SelectionChanged, AddressOf RTB_SelectionChanged
        AddHandler rtb.TextChanged, AddressOf RTB_TextChanged_Status
        Dim tab As New TabPage(title)
        tab.ImageIndex = 0
        tab.Controls.Add(rtb)

        TabControl1.TabPages.Add(tab)
        TabControl1.SelectedTab = tab
        lbtabname.Text = "Tab - " + title
        rtb.Focus()
        tabFilePaths(tab) = ""  ' default belum ada file
        tabModified(tab) = False
        UpdateFormTitle()

    End Sub
    Private Sub RTB_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs)
        UpdateStatusBar()
        Dim rtb = GetActiveRTB()
        If rtb IsNot Nothing AndAlso rtb.SelectionFont IsNot Nothing Then
            ToolStripButton1.Checked = rtb.SelectionFont.Bold
            ToolStripButton7.Checked = rtb.SelectionFont.Italic
            ToolStripButton8.Checked = rtb.SelectionFont.Underline
        End If
        UpdateAlignmentButtons(rtb)

        ' Cek apakah seleksi mengandung gambar
        ToolStripButton17.Enabled = SelectionHasImage(rtb)
    End Sub
    Private Function SelectionHasImage(ByVal rtb As RichTextBox) As Boolean
        Dim selectedRtf As String = rtb.SelectedRtf

        If String.IsNullOrEmpty(selectedRtf) Then Return False

        ' Cari keyword gambar dalam RTF
        ' \pict biasanya menandakan gambar OLE
        If selectedRtf.IndexOf("\pict", StringComparison.OrdinalIgnoreCase) >= 0 Then
            Return True
        End If

        Return False

    End Function
    Private Sub RTB_TextChanged_Status(ByVal sender As Object, ByVal e As EventArgs)
        UpdateStatusBar()
    End Sub
    Private Sub BlinkTick(ByVal sender As Object, ByVal e As EventArgs)
        If blinkTarget Is Nothing Then Exit Sub

        If blinkTarget.BackColor = Color.White Then
            blinkTarget.BackColor = Color.LightPink
        Else
            blinkTarget.BackColor = Color.White
        End If

        blinkCount += 1

        ' 4 tick = 2x kedip
        If blinkCount >= 4 Then
            blinkTimer.Stop()
            blinkTarget.BackColor = Color.White
            blinkCount = 0
            isBlinking = False
        End If
    End Sub
    Private Sub RichTextBox_TextChanged(ByVal sender As Object, ByVal e As EventArgs)
        If isLoadingFile Then Exit Sub ' <--- skip jika sedang load file

        Dim rtb As RichTextBox = CType(sender, RichTextBox)
        Dim tab As TabPage = CType(rtb.Parent, TabPage)

        If Not tabModified(tab) Then
            tab.Text = "*" & tab.Text
            tabModified(tab) = True
        End If
        If rtb.TextLength >= rtb.MaxLength AndAlso Not isBlinking Then
            isBlinking = True
            blinkTarget = rtb
            blinkCount = 0
            blinkTimer.Start()
            MsgBox("Your Notesec is not registered, the available limit is 500 characters." & vbNewLine & "Register Notesec to get unlimited writing and free custom passwords.", vbExclamation, "Unregistered version")
            frmRegister.ShowDialog()
        End If
        UpdateMenuState()
        UpdateStatusBar()
    End Sub

    Private Sub Form1_DragDrop(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragDrop
        Dim files() As String = CType(e.Data.GetData(DataFormats.FileDrop), String())

        For Each filePath As String In files
            Try
                If File.Exists(filePath) AndAlso
                   String.Equals(Path.GetExtension(filePath), ".ns", StringComparison.OrdinalIgnoreCase) Then

                    ' === CEK SUDAH TERBUKA ===
                    Dim alreadyOpen As Boolean = False

                    For Each kvp In tabFilePaths
                        If String.Compare(kvp.Value, filePath, True) = 0 Then
                            TabControl1.SelectedTab = kvp.Key
                            alreadyOpen = True
                            Exit For
                        End If
                    Next

                    ' === BUKA JIKA BELUM ===
                    If Not alreadyOpen Then
                        OpenRTF(filePath)
                    End If

                End If
            Catch ex As Exception
                MessageBox.Show(
                    "Failed to open file:" & Environment.NewLine &
                    filePath & Environment.NewLine & Environment.NewLine &
                    ex.Message,
                    "Drag & Drop Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                )
            End Try
        Next
    End Sub

    Private Sub Form1_DragEnter(ByVal sender As Object, ByVal e As System.Windows.Forms.DragEventArgs) Handles Me.DragEnter
        If e.Data.GetDataPresent(DataFormats.FileDrop) Then
            e.Effect = DragDropEffects.Copy
        Else
            e.Effect = DragDropEffects.None
        End If
    End Sub

    Private Sub Form1_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        ' Loop semua tab, cek yang modified
        For Each tab As TabPage In TabControl1.TabPages
            If tabModified(tab) Then
                ' Tanyakan untuk menyimpan
                Dim result As DialogResult = MessageBox.Show("File '" & tab.Text.TrimStart("*"c) & "' has not been saved. Do you want to save it now?", "Confirmation", MessageBoxButtons.YesNoCancel)

                If result = DialogResult.Yes Then
                    ' Simpan file
                    TabControl1.SelectedTab = tab
                    SaveToolStripMenuItem_Click(Me, EventArgs.Empty)
                    ' Setelah save, lanjut cek tab berikutnya
                ElseIf result = DialogResult.Cancel Then
                    ' Batalkan closing
                    e.Cancel = True
                    Exit Sub
                ElseIf result = DialogResult.No Then
                    ' Tidak perlu simpan, lanjut ke tab berikutnya
                    Continue For
                End If
            End If
        Next
    End Sub
    Private hwidThread As Thread
    Private Sub GetHWID_Thread()
        Try
            Dim hwid As String = GetHWID()

            Me.Invoke(New MethodInvoker(Sub()
                                            userpassword = hwid
                                            defaultpassword = hwid
                                        End Sub))

        Catch
            Me.Invoke(New MethodInvoker(Sub()
                                            userpassword = "123"
                                            defaultpassword = "123"
                                        End Sub))
        End Try
    End Sub
    Sub cekregister()
        If File.Exists(regpath) Then
            isregistered = True
            BuyOnlineToolStripMenuItem.Visible = False
            EnterRegistrationKeyToolStripMenuItem.Visible = False
            btnunregistered.Visible = False
            SetWindowDisplayAffinity(Me.Handle, WDA_MONITOR)
        Else
            isregistered = False
            btnunregistered.Visible = True
            frmRegister.Height = 242
            frmRegister.LinkLabel1.Visible = True
            frmRegister.ShowDialog()
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Icon = My.Resources.Notesecicon
        If Not IsNSAssociated() Then
            AssociateNSFile()
        End If
        cekregister()
        loadata()
        blinkTimer.Interval = 100 ' kecepatan kedip
        AddHandler blinkTimer.Tick, AddressOf BlinkTick
        hwidThread = New Thread(AddressOf GetHWID_Thread)
        hwidThread.IsBackground = True
        hwidThread.Start()
        Dim imgList As New ImageList()
        imgList.ImageSize = New Size(16, 16)
        imgList.ColorDepth = ColorDepth.Depth32Bit
        imgList.Images.Add("text", My.Resources.docs)
        TabControl1.ImageList = imgList
        ' ================================
        ' HANDLE FILE ASSOCIATION (.ns)
        ' SUPPORT MULTI FILE
        ' ================================
        Dim args() As String = Environment.GetCommandLineArgs()
        Dim openedAnyFile As Boolean = False

        If args.Length > 1 Then
            For i As Integer = 1 To args.Length - 1
                Dim filePath As String = args(i)

                If File.Exists(filePath) AndAlso
                   String.Equals(Path.GetExtension(filePath), ".ns", StringComparison.OrdinalIgnoreCase) Then

                    OpenRTF(filePath)
                    openedAnyFile = True
                End If
            Next
        End If

        ' Jika TIDAK ada file dari command line
        If Not openedAnyFile Then
            AddNewTab()
        End If

        UpdateMenuState()
    End Sub
    Private Sub NewToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewToolStripMenuItem.Click
        AddNewTab()
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        Dim tab As TabPage = TabControl1.SelectedTab
        If tabFilePaths(tab) = "" Then
            SaveAsToolStripMenuItem_Click(sender, e)
            Exit Sub
        End If

        SaveRTF(tab, tabFilePaths(tab))
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveAsToolStripMenuItem.Click


        '=== LANJUT PROSES SAVE AS ===
        Dim tab As TabPage = TabControl1.SelectedTab
        If tab Is Nothing Then Exit Sub

        Dim sfd As New SaveFileDialog()
        sfd.Filter = "Notesec Files (*.ns)|*.ns"
        sfd.DefaultExt = "ns"

        If sfd.ShowDialog() <> DialogResult.OK Then Exit Sub

        tabFilePaths(tab) = sfd.FileName
        SaveRTF(tab, sfd.FileName)
    End Sub

    Private Sub NewWindowToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NewWindowToolStripMenuItem.Click
        Process.Start(Application.ExecutablePath)
    End Sub

    Private Sub OpenToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenToolStripMenuItem.Click


        '=== LANJUT OPEN FILE ===
        Dim ofd As New OpenFileDialog()
        ofd.Filter = "Notesec Files (*.ns)|*.ns"
        ofd.DefaultExt = "ns"

        If ofd.ShowDialog() <> DialogResult.OK Then Exit Sub

        OpenRTF(ofd.FileName)
    End Sub

    Private Sub PageSetupToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PageSetupToolStripMenuItem.Click
        pageSetup.Document = printDoc
        pageSetup.ShowDialog()
    End Sub

    Private Sub PrintToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintToolStripMenuItem.Click
        Dim pd As New PrintDialog()
        pd.Document = printDoc
        If pd.ShowDialog() = DialogResult.OK Then
            printDoc.Print()
        End If
    End Sub
    Private Sub printDoc_PrintPage(ByVal sender As Object, ByVal e As Printing.PrintPageEventArgs) _
        Handles printDoc.PrintPage

        Dim rtb As RichTextBox = GetActiveRTB()
        If rtb Is Nothing Then Exit Sub

        e.Graphics.DrawString(rtb.Text, rtb.Font, Brushes.Black, e.MarginBounds)
    End Sub
    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        For Each tab As TabPage In TabControl1.TabPages
            If tabModified(tab) Then
                Dim res = MessageBox.Show("There are unsaved files. Exit?", "Confirmation", MessageBoxButtons.YesNo)
                If res = DialogResult.No Then Exit Sub
                Exit For
            End If
        Next
        Application.Exit()
    End Sub

    Private Sub UndoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UndoToolStripMenuItem.Click
        Dim rtb = GetActiveRTB()
        If rtb IsNot Nothing AndAlso rtb.CanUndo Then rtb.Undo()
    End Sub

    Private Sub CutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CutToolStripMenuItem.Click
        GetActiveRTB().Cut()
    End Sub

    Private Sub CopyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CopyToolStripMenuItem.Click
        GetActiveRTB().Copy()
    End Sub

    Private Sub PasteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PasteToolStripMenuItem.Click
        GetActiveRTB().Paste()
    End Sub

    Private Sub DeleteToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteToolStripMenuItem.Click
        Dim rtb = GetActiveRTB()
        rtb.SelectedText = ""
    End Sub
    Public Sub FindText(ByVal text As String, ByVal matchCase As Boolean, ByVal nextFind As Boolean)
        Dim rtb As RichTextBox = GetActiveRTB()
        If rtb Is Nothing Or text = "" Then Exit Sub

        Dim comp As StringComparison = If(matchCase, StringComparison.Ordinal, StringComparison.OrdinalIgnoreCase)

        Dim startIndex As Integer
        If nextFind Then
            startIndex = rtb.SelectionStart + rtb.SelectionLength
        Else
            startIndex = 0
        End If

        lastFindIndex = rtb.Text.IndexOf(text, startIndex, comp)

        If lastFindIndex >= 0 Then
            rtb.Select(lastFindIndex, text.Length)
            rtb.ScrollToCaret()
        Else
            MessageBox.Show("Text not found.")
        End If
    End Sub
    Public Sub FindTextPrevious(ByVal text As String, ByVal matchCase As Boolean)
        Dim rtb As RichTextBox = GetActiveRTB()
        If rtb Is Nothing Or text = "" Then Exit Sub

        Dim comp As StringComparison = If(matchCase, StringComparison.Ordinal, StringComparison.OrdinalIgnoreCase)

        Dim startIndex As Integer = rtb.SelectionStart - 1
        If startIndex < 0 Then Exit Sub

        lastFindIndex = rtb.Text.LastIndexOf(text, startIndex, comp)

        If lastFindIndex >= 0 Then
            rtb.Select(lastFindIndex, text.Length)
            rtb.ScrollToCaret()
        Else
            MessageBox.Show("No previous match.")
        End If
    End Sub
    Private Sub FindToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FindToolStripMenuItem.Click
        txtfind.Focus()
    End Sub

    Private Sub ReplaceToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ReplaceToolStripMenuItem.Click
        Dim rtb As RichTextBox = GetActiveRTB()
        If rtb Is Nothing Then Exit Sub

        Dim findText As String = InputBox("Search text:", "Replace")
        If findText = "" Then Exit Sub

        Dim replaceText As String = InputBox("Replace with:", "Replace")

        Dim choice = MessageBox.Show("Replace All?", "Replace", MessageBoxButtons.YesNoCancel)

        If choice = DialogResult.Cancel Then Exit Sub

        If choice = DialogResult.Yes Then
            rtb.Text = rtb.Text.Replace(findText, replaceText)
        Else
            ' Replace satu (yang sedang dipilih)
            Dim idx As Integer = rtb.Text.IndexOf(findText, StringComparison.OrdinalIgnoreCase)
            If idx >= 0 Then
                rtb.Select(idx, findText.Length)
                rtb.SelectedText = replaceText
            Else
                MessageBox.Show("Text not found.")
            End If
        End If
    End Sub

    Private Sub SelectAllToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SelectAllToolStripMenuItem.Click
        GetActiveRTB().SelectAll()
    End Sub

    Private Sub WordWrapToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WordWrapToolStripMenuItem.Click
        Dim rtb = GetActiveRTB()
        rtb.WordWrap = Not rtb.WordWrap
        WordWrapToolStripMenuItem.Checked = rtb.WordWrap
    End Sub

    Private Sub FontToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FontToolStripMenuItem.Click
        Dim fd As New FontDialog()
        Dim rtb = GetActiveRTB()
        fd.Font = rtb.Font

        If fd.ShowDialog() = DialogResult.OK Then
            rtb.Font = fd.Font
        End If
    End Sub

    Private Sub ZoomInToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ZoomInToolStripMenuItem.Click
        currentZoom += 0.1F
        GetActiveRTB().ZoomFactor = currentZoom
        UpdateStatusBar()
    End Sub

    Private Sub ZoomOutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ZoomOutToolStripMenuItem.Click
        currentZoom -= 0.1F
        If currentZoom < 0.2F Then currentZoom = 0.2F
        GetActiveRTB().ZoomFactor = currentZoom
        UpdateStatusBar()
    End Sub

    Private Sub RestoreDefaultZoomToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RestoreDefaultZoomToolStripMenuItem.Click
        currentZoom = 1.0F
        GetActiveRTB().ZoomFactor = currentZoom
        UpdateStatusBar()
    End Sub

    Private Sub StatusBarToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles StatusBarToolStripMenuItem.Click
        StatusStrip1.Visible = Not StatusStrip1.Visible
        StatusBarToolStripMenuItem.Checked = StatusStrip1.Visible
    End Sub

    Private Sub HelpToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TabControl1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TabControl1.SelectedIndexChanged
        UpdateMenuState()
        UpdateStatusBar()
        UpdateFormTitle()
    End Sub

    Private Sub ToolStripButton6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton6.Click
        Dim tab As TabPage = TabControl1.SelectedTab
        If tabModified(tab) Then
            Dim res As DialogResult = MessageBox.Show("File not saved. Save now?", "Confirmation", MessageBoxButtons.YesNoCancel)
            If res = DialogResult.Yes Then
                SaveToolStripMenuItem_Click(sender, e)
            ElseIf res = DialogResult.Cancel Then
                Return
            End If
        End If

        ' Hapus data tab
        tabFilePaths.Remove(tab)
        tabModified.Remove(tab)
        TabControl1.TabPages.Remove(tab)

        ' Jika semua tab sudah ditutup, keluar program
        If TabControl1.TabPages.Count = 0 Then
            Application.Exit()
        End If
    End Sub

    Private Sub ToolStripButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton2.Click
        FindText(txtfind.Text, False, False)
    End Sub

    Private Sub ToolStripButton3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton3.Click
        FindText(txtfind.Text, False, True)
    End Sub

    Private Sub ToolStripButton4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton4.Click
        FindTextPrevious(txtfind.Text, False)
    End Sub

    Private Sub ToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton1.Click
        Dim rtb = GetActiveRTB()
        If rtb IsNot Nothing AndAlso rtb.SelectionFont IsNot Nothing Then
            Dim currentFont As Font = rtb.SelectionFont
            Dim newFontStyle As FontStyle

            If currentFont.Bold Then
                newFontStyle = currentFont.Style And Not FontStyle.Bold
            Else
                newFontStyle = currentFont.Style Or FontStyle.Bold
            End If

            rtb.SelectionFont = New Font(currentFont, newFontStyle)

            ' Update state tombol
            ToolStripButton1.Checked = rtb.SelectionFont.Bold
        End If
    End Sub

    Private Sub ToolStripButton7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton7.Click
        Dim rtb = GetActiveRTB()
        If rtb IsNot Nothing AndAlso rtb.SelectionFont IsNot Nothing Then
            Dim currentFont As Font = rtb.SelectionFont
            Dim newFontStyle As FontStyle

            If currentFont.Italic Then
                newFontStyle = currentFont.Style And Not FontStyle.Italic
            Else
                newFontStyle = currentFont.Style Or FontStyle.Italic
            End If

            rtb.SelectionFont = New Font(currentFont, newFontStyle)
            ToolStripButton7.Checked = rtb.SelectionFont.Italic
        End If
    End Sub

    Private Sub ToolStripButton8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton8.Click
        Dim rtb = GetActiveRTB()
        If rtb IsNot Nothing AndAlso rtb.SelectionFont IsNot Nothing Then
            Dim currentFont As Font = rtb.SelectionFont
            Dim newFontStyle As FontStyle

            If currentFont.Underline Then
                newFontStyle = currentFont.Style And Not FontStyle.Underline
            Else
                newFontStyle = currentFont.Style Or FontStyle.Underline
            End If

            rtb.SelectionFont = New Font(currentFont, newFontStyle)
            ToolStripButton8.Checked = rtb.SelectionFont.Underline
        End If
    End Sub

    Private Sub ToolStripButton9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton9.Click
        Dim rtb = GetActiveRTB()
        Dim cd As New ColorDialog()

        If cd.ShowDialog() = DialogResult.OK Then
            rtb.SelectionColor = cd.Color
        End If
    End Sub

    Private Sub ToolStripButton10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton10.Click
        Dim fd As New FontDialog()
        Dim rtb = GetActiveRTB()
        fd.Font = rtb.Font

        If fd.ShowDialog() = DialogResult.OK Then
            rtb.Font = fd.Font
        End If
    End Sub

    Private Sub txturl_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub


    Private Sub ToolStripButton11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton11.Click
        Dim rtb = GetActiveRTB()
        If rtb IsNot Nothing Then
            rtb.SelectionAlignment = HorizontalAlignment.Left
            UpdateAlignmentButtons(rtb)
        End If
    End Sub

    Private Sub ToolStripButton12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton12.Click
        Dim rtb = GetActiveRTB()
        If rtb IsNot Nothing Then
            rtb.SelectionAlignment = HorizontalAlignment.Center
            UpdateAlignmentButtons(rtb)
        End If
    End Sub

    Private Sub ToolStripButton13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton13.Click
        Dim rtb = GetActiveRTB()
        If rtb IsNot Nothing Then
            rtb.SelectionAlignment = HorizontalAlignment.Right
            UpdateAlignmentButtons(rtb)
        End If
    End Sub
    Private Sub UpdateAlignmentButtons(ByVal rtb As RichTextBox)
        ToolStripButton11.Checked = (rtb.SelectionAlignment = HorizontalAlignment.Left)
        ToolStripButton12.Checked = (rtb.SelectionAlignment = HorizontalAlignment.Center)
        ToolStripButton13.Checked = (rtb.SelectionAlignment = HorizontalAlignment.Right)
    End Sub
    Dim appFolder As String = Path.Combine( _
       Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), _
       "Notesec")

    Dim dataFile As String
    Sub recent()
        Try
            ' Buat folder jika belum ada
            If Not Directory.Exists(appFolder) Then
                Directory.CreateDirectory(appFolder)
            End If

            dataFile = Path.Combine(appFolder, "recent.txt")

            ' Simpan items unik
            Dim writtenItems As New System.Collections.ArrayList()

            Using sw As New StreamWriter(dataFile, False)
                For Each item As Object In ListBox1.Items
                    Dim text As String = item.ToString()
                    If Not writtenItems.Contains(text) Then
                        sw.WriteLine(text)
                        writtenItems.Add(text)
                    End If
                Next
            End Using

            ' MessageBox.Show("Data berhasil disimpan")

        Catch ex As Exception
            MessageBox.Show("Failed: " & ex.Message)
        End Try
    End Sub
    Sub AddItemUnique(ByVal item As String)
        ' Cegah duplikat di ListBox
        Dim exists As Boolean = False
        For Each i As Object In ListBox1.Items
            If String.Compare(i.ToString(), item, True) = 0 Then
                exists = True
                Exit For
            End If
        Next

        If Not exists Then
            ListBox1.Items.Add(item)
        End If
    End Sub

    Sub loadata()
        Try
            dataFile = Path.Combine(appFolder, "recent.txt")

            If File.Exists(dataFile) Then
                ListBox1.Items.Clear()

                Using sr As New StreamReader(dataFile)
                    While Not sr.EndOfStream
                        AddItemUnique(sr.ReadLine())
                    End While
                End Using
            End If

        Catch ex As Exception
            'MessageBox.Show("Gagal load data: " & ex.Message)
        End Try
    End Sub

    Private Sub SaveRTFThreadSafe(ByVal state As Object)
        Try
            Dim arr() As Object = CType(state, Object())
            Dim tab As TabPage = CType(arr(0), TabPage)
            Dim rtfText As String = CType(arr(1), String)
            Dim filePath As String = CType(arr(2), String)

            ' === PASSWORD ===
            Using f As New frmPassword()
                If f.ShowDialog() <> DialogResult.OK Then Exit Sub
                userpassword = f.Password   ' <<< FIX PENTING
            End Using

            Me.Invoke(New MethodInvoker(Sub()
                                            ToggleControls(False)
                                            ProgressBar1.Visible = True
                                            lbstatus.Visible = True
                                            ProgressBar1.Value = 0
                                            lbstatus.Text = "Saving and encrypting file..."
                                        End Sub))

            ' === HEADER DITAMBAHKAN ===
            Dim plainText As String = "NOTESEC|NOTES|" & rtfText

            Dim encryptedText As String =
                ModuleEncryptAES.EncryptText(plainText, userpassword,
                    New ModuleEncryptAES.ProgressCallback(AddressOf UpdateProgress))

            File.WriteAllText(filePath, encryptedText, Encoding.UTF8)

            Me.Invoke(New MethodInvoker(Sub()
                                            tabModified(tab) = False
                                            If tab.Text.StartsWith("*") Then tab.Text = tab.Text.Substring(1)
                                            tab.Text = Path.GetFileName(filePath)
                                            lbtabname.Text = "Tab - " & Path.GetFileName(filePath)
                                            ListBox1.Items.Add(filePath)
                                            recent()
                                            loadata()
                                            ProgressBar1.Visible = False
                                            lbstatus.Visible = False
                                            ToggleControls(True)
                                            UpdateFormTitle()
                                            UpdateMenuState()
                                            UpdateStatusBar()
                                        End Sub))

        Catch ex As Exception
            Me.Invoke(New MethodInvoker(Sub()
                                            ProgressBar1.Visible = False
                                            lbstatus.Visible = False
                                            ToggleControls(True)
                                            MessageBox.Show(
     "The file could not be saved due to an unexpected error." & Environment.NewLine &
     "Details: " & ex.Message,
     "Save Error",
     MessageBoxButtons.OK,
     MessageBoxIcon.Error
 )

                                        End Sub))
        End Try
    End Sub

    Private Sub SaveRTF(ByVal tab As TabPage, ByVal filePath As String)
        ' Ambil RTF dulu di thread utama
        Dim rtb As RichTextBox = CType(tab.Controls(0), RichTextBox)
        Dim rtfText As String = rtb.Rtf

        ' Jalankan thread
        Dim t As New Threading.Thread(AddressOf SaveRTFThreadSafe)
        t.IsBackground = True
        t.Start(New Object() {tab, rtfText, filePath})
    End Sub
    Private Sub OpenRTFThreadSafe(ByVal state As Object)
        Dim filePath As String = CType(state, String)

        '=== CEK FILE SUDAH DIBUKA ===
        For Each kvp In tabFilePaths
            If String.Compare(kvp.Value, filePath, True) = 0 Then
                Dim localTab As TabPage = kvp.Key
                Me.Invoke(New MethodInvoker(Sub()
                                                TabControl1.SelectedTab = localTab
                                                MessageBox.Show(
    "This file is already open.",
    "Information",
    MessageBoxButtons.OK,
    MessageBoxIcon.Information
)

                                            End Sub))
                Return
            End If
        Next

        Dim cipherText As String = ""
        Try
            cipherText = File.ReadAllText(filePath)
        Catch ex As Exception
            Me.Invoke(New MethodInvoker(Sub()
                                            MessageBox.Show(
      "The file could not be read." & Environment.NewLine &
      "Please ensure the file exists and you have sufficient access rights." & Environment.NewLine &
      "Details: " & ex.Message,
      "File Read Error",
      MessageBoxButtons.OK,
      MessageBoxIcon.Error
  )

                                        End Sub))
            Return
        End Try

        ' ===============================
        ' LOOP PASSWORD
        ' ===============================
        While True

            ' === PASSWORD DIALOG ===
            Using f As New frmPassword()
                If f.ShowDialog() <> DialogResult.OK Then
                    Exit Sub ' cancel
                End If
                userpassword = f.Password
            End Using

            Try
                Me.Invoke(New MethodInvoker(Sub()
                                                ToggleControls(False)
                                                ProgressBar1.Visible = True
                                                lbstatus.Visible = True
                                                ProgressBar1.Value = 0
                                                lbstatus.Text = "Opening and decrypting file..."
                                            End Sub))

                Dim plainText As String =
                    ModuleEncryptAES.DecryptText(cipherText, userpassword,
                        New ModuleEncryptAES.ProgressCallback(AddressOf UpdateProgress))

                ' === VALIDASI HEADER ===
                If Not plainText.StartsWith("NOTESEC|NOTES|") Then
                    Throw New CryptographicException("Password salah.")
                End If

                Dim rtfText As String = plainText.Substring("NOTESEC|NOTES|".Length)

                ' === BERHASIL ===
                Me.Invoke(New MethodInvoker(Sub()
                                                AddNewTab(Path.GetFileName(filePath))
                                                Dim rtb As RichTextBox = GetActiveRTB()
                                                isLoadingFile = True
                                                rtb.Rtf = rtfText
                                                isLoadingFile = False

                                                Dim tab As TabPage = TabControl1.SelectedTab
                                                tabFilePaths(tab) = filePath
                                                tabModified(tab) = False

                                                ProgressBar1.Value = 100
                                                ProgressBar1.Visible = False
                                                lbstatus.Visible = False
                                                ToggleControls(True)
                                            End Sub))
                Exit Sub ' keluar loop (sukses)

            Catch ex As CryptographicException
                ' === PASSWORD SALAH ===
                Me.Invoke(New MethodInvoker(Sub()
                                                ProgressBar1.Visible = False
                                                lbstatus.Visible = False
                                                ToggleControls(True)
                                                MessageBox.Show(
        "The password you entered is incorrect." & Environment.NewLine &
        "Please try again.",
        "Incorrect Password",
        MessageBoxButtons.OK,
        MessageBoxIcon.Warning
    )

                                            End Sub))
                ' loop lanjut → frmPassword muncul lagi

            Catch ex As Exception
                Me.Invoke(New MethodInvoker(Sub()
                                                ProgressBar1.Visible = False
                                                lbstatus.Visible = False
                                                ToggleControls(True)
                                                MessageBox.Show(
     "The file could not be opened due to an unexpected error." & Environment.NewLine &
     "Details: " & ex.Message,
     "Open File Error",
     MessageBoxButtons.OK,
     MessageBoxIcon.Error
 )

                                            End Sub))
                Exit Sub
            End Try

        End While
    End Sub
    Private Sub OpenRTF(ByVal filePath As String)
        Dim t As New Threading.Thread(AddressOf OpenRTFThreadSafe)
        t.IsBackground = True
        t.Start(filePath)
    End Sub
    ' Callback progress
    Private Sub UpdateProgress(ByVal percent As Integer)
        Me.Invoke(New MethodInvoker(Sub()
                                        ProgressBar1.Value = percent
                                    End Sub))
    End Sub
    Private Sub ToggleControls(ByVal enable As Boolean)
        TabControl1.Enabled = enable
        TabControl2.Enabled = enable
        MenuStrip1.Enabled = enable
        ToolStrip1.Enabled = enable
        ToolStrip2.Enabled = enable
    End Sub


    Private Sub ToolStripButton14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton14.Click
        Dim rtb As RichTextBox = GetActiveRTB()
        If rtb Is Nothing Then Exit Sub

        Dim ofd As New OpenFileDialog()
        ofd.Filter = "Image Files|*.bmp;*.jpg;*.jpeg;*.png;*.gif"

        If ofd.ShowDialog() = DialogResult.OK Then
            Try
                ' Cek ukuran file
                Dim fi As New IO.FileInfo(ofd.FileName)
                If fi.Length > 1048576 Then ' >1 MB
                    MessageBox.Show("Image is too large! Maximum 1 MB.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning)
                    Exit Sub
                End If

                Dim img As Image = Image.FromFile(ofd.FileName)
                InsertImageIntoRTB(rtb, img)
            Catch ex As Exception
                MessageBox.Show("Failed to insert image: " & ex.Message)
            End Try
        End If
    End Sub

    Private Sub InsertImageIntoRTB(ByVal rtb As RichTextBox, ByVal img As Image)
        If img Is Nothing Then Exit Sub

        ' Simpan isi clipboard sementara
        Dim oldClipboard As IDataObject = Clipboard.GetDataObject()

        ' Masukkan gambar ke clipboard
        Clipboard.SetImage(img)

        ' Paste ke RichTextBox
        rtb.Paste()

        ' Kembalikan clipboard sebelumnya
        If oldClipboard IsNot Nothing Then
            Clipboard.SetDataObject(oldClipboard)
        End If
    End Sub



    Private Function IsValidUrl(ByVal url As String) As Boolean
        Dim pattern As String = "^(http|https)://([\w-]+\.)+[\w-]+(/[\w- ./?%&=]*)?$"
        Return Regex.IsMatch(url, pattern, RegexOptions.IgnoreCase)
    End Function

    Private Sub ListBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.DoubleClick
        If ListBox1.SelectedIndex <> -1 Then
            Dim rawItem As String = ListBox1.SelectedItem.ToString()
            OpenRTF(rawItem)
        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        If ListBox1.SelectedIndex <> -1 Then
            Me.ActiveControl = Nothing
            ToolStrip3.Enabled = True
        Else
            Me.ActiveControl = Nothing
            ToolStrip3.Enabled = False
        End If
    End Sub

    Private Sub ToolStripButton16_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton16.Click
        Me.ActiveControl = Nothing
        If ListBox1.SelectedIndex <> -1 Then
            Dim index As Integer = ListBox1.SelectedIndex
            Dim selectedItem As String = ListBox1.Items(index).ToString()

            If File.Exists(selectedItem) Then
                File.Delete(selectedItem)
            End If

            ListBox1.Items.RemoveAt(index)
            recent()
        End If

    End Sub

    Private Sub RightPanelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RightPanelToolStripMenuItem.Click
        If RightPanelToolStripMenuItem.Checked Then
            RightPanelToolStripMenuItem.Checked = False
            TabControl2.Visible = False
        Else
            RightPanelToolStripMenuItem.Checked = True
            TabControl2.Visible = True
        End If
    End Sub

    Private Sub ToolStripButton17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton17.Click
        Dim rtb = GetActiveRTB()
        Dim images As List(Of Image) = ExtractImagesFromRtf(rtb.SelectedRtf)

        If images.Count = 0 Then
            MessageBox.Show("No images could be extracted.")
            Exit Sub
        End If

        For i As Integer = 0 To images.Count - 1
            Using sfd As New SaveFileDialog()
                sfd.Filter = "PNG Image|*.png|JPEG Image|*.jpg"
                sfd.FileName = "image_" & i
                sfd.Title = "Save image to file"

                If sfd.ShowDialog() = DialogResult.OK Then
                    ' Tentukan format berdasarkan ekstensi
                    Dim ext As String = Path.GetExtension(sfd.FileName).ToLower()
                    If ext = ".jpg" Or ext = ".jpeg" Then
                        images(i).Save(sfd.FileName, Imaging.ImageFormat.Jpeg)
                    Else
                        images(i).Save(sfd.FileName, Imaging.ImageFormat.Png)
                    End If
                End If
            End Using
        Next

        MessageBox.Show(images.Count & " image was successfully extracted and saved.")

    End Sub



    Private Sub ToolStripButton18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton18.Click
        Dim rtb = GetActiveRTB()
        If rtb.SelectionLength > 0 Then
            Dim currentFont As Font = rtb.SelectionFont
            Dim newSize As Single = currentFont.Size + 2 ' tambah 2 poin
            rtb.SelectionFont = New Font(currentFont.FontFamily, newSize, currentFont.Style)
        End If
    End Sub

    Private Sub ToolStripButton19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton19.Click
        Dim rtb = GetActiveRTB()
        If rtb.SelectionLength > 0 Then
            Dim currentFont As Font = rtb.SelectionFont
            Dim newSize As Single = currentFont.Size - 2
            If newSize < 1 Then newSize = 1
            rtb.SelectionFont = New Font(currentFont.FontFamily, newSize, currentFont.Style)
        End If
    End Sub

    Private Sub AboutOwlackToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutOwlackToolStripMenuItem.Click
        frmAbout.ShowDialog()
    End Sub

    Private Sub btnunregistered_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnunregistered.Click
        frmRegister.ShowDialog()

    End Sub

    Private Sub EnterRegistrationKeyToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EnterRegistrationKeyToolStripMenuItem.Click
        frmRegister.ShowDialog()
    End Sub

    Private Sub DelToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DelToolStripMenuItem.Click
        If File.Exists(regpath) Then
            File.Delete(regpath)
            Application.Restart()
        End If
    End Sub

    Private Sub ToolStripButton5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnopen.Click
        OpenToolStripMenuItem.PerformClick()
    End Sub

    Private Sub ToolStripButton15_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnew.Click
        NewToolStripMenuItem.PerformClick()
    End Sub

    Private Sub ToolStripButton20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnnewwindow.Click
        NewWindowToolStripMenuItem.PerformClick()
    End Sub

    Private Sub btnsave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsave.Click
        SaveToolStripMenuItem.PerformClick()
    End Sub

    Private Sub btnsaveas_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnsaveas.Click
        SaveAsToolStripMenuItem.PerformClick()
    End Sub

    Private Sub btnpagestup_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnpagestup.Click
        PageSetupToolStripMenuItem.PerformClick()
    End Sub

    Private Sub btnprint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnprint.Click
        PrintToolStripMenuItem.PerformClick()
    End Sub

    Private Sub ToolStripButton5_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton5.Click
        frmFTP.ShowDialog()
    End Sub

    Private Sub ToolStripButton15_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripButton15.Click
        If ListBox1.SelectedIndex <> -1 Then
            Dim selfile As String = ListBox1.SelectedItem.ToString
            frmFTP.txtLocalFile.Text = selfile
            frmFTP.ShowDialog()
        End If
    End Sub

    Private Sub BuyOnlineToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BuyOnlineToolStripMenuItem.Click
        frmBuy.ShowDialog()
    End Sub

    Private Sub HomepageToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HomepageToolStripMenuItem.Click
        Process.Start("https://notesec.github.io/")
    End Sub

    Private Sub LicenseToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LicenseToolStripMenuItem.Click
        frmLicense.ShowDialog()
    End Sub
End Class

