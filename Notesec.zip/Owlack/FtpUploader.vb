﻿Imports System.Diagnostics
Imports System.IO
Imports System.Text
Imports System.Threading

Public Class FtpUploader

    Public Enum ProtocolType
        FTP
        FTPS
        SFTP
    End Enum

    Public Enum SSLModeType
        None
        ExplicitTLS
        Insecure
    End Enum

    Public Shared Function UploadFile( _
        ByVal curlPath As String, _
        ByVal localFile As String, _
        ByVal host As String, _
        ByVal port As Integer, _
        ByVal username As String, _
        ByVal password As String, _
        ByVal remotePath As String, _
        ByVal protocol As ProtocolType, _
        ByVal sslMode As SSLModeType _
    ) As String

        If Not File.Exists(localFile) Then
            Return "ERROR: Local file not found"
        End If

        If Not File.Exists(curlPath) Then
            Return "ERROR: curl.exe not found"
        End If

        Dim proto As String = "ftp"
        Select Case protocol
            Case ProtocolType.FTPS : proto = "ftps"
            Case ProtocolType.SFTP : proto = "sftp"
        End Select

        Dim url As String = proto & "://" & host
        If port > 0 Then url &= ":" & port
        url &= "/" & remotePath.TrimStart("/"c)

        Dim args As New StringBuilder()

        args.Append("-T """ & localFile & """ ")
        args.Append("""" & url & """ ")
        args.Append("--user """ & username & ":" & password & """ ")

        Select Case sslMode
            Case SSLModeType.ExplicitTLS
                args.Append("--ssl ")
            Case SSLModeType.Insecure
                args.Append("-k ")
        End Select

        args.Append("--connect-timeout 30 ")
        args.Append("--max-time 300 ")
        args.Append("--retry 2 ")
        args.Append("--silent --show-error ")

        Dim psi As New ProcessStartInfo()
        psi.FileName = curlPath
        psi.Arguments = args.ToString()
        psi.UseShellExecute = False
        psi.RedirectStandardOutput = True
        psi.RedirectStandardError = True
        psi.CreateNoWindow = True

        Dim p As Process = Process.Start(psi)
        Dim output As String = p.StandardOutput.ReadToEnd()
        Dim err As String = p.StandardError.ReadToEnd()
        p.WaitForExit()

        If p.ExitCode = 0 Then
            Return "File UPLOADED!"
        Else
            Return "ERROR: " & err.Trim()
        End If

    End Function

End Class
