﻿Imports System.IO

Public Class frmRegister
    Private filePath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "data.reg")
    Sub cekhash()
        Dim input As String = TextBox1.Text
        Dim hashToCheck As String = lbout.Text

        If HashingModule.VerifySerialHash(input, hashToCheck) Then
            Dim lines As String() = {TextBox1.Text, lbout.Text}
            File.WriteAllLines(filePath, lines)
            MessageBox.Show("Thank You !" & vbNewLine & "You have registered." & vbNewLine & "For questions and technical support?" & vbNewLine & "notesec@hotmail.com", "Registration Successful!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Application.Restart()
        Else
            MessageBox.Show("Please double-check your product key in the email we sent you.", "Incorrect Registration Key!", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If String.IsNullOrEmpty(TextBox1.Text) Then
            MsgBox("Enter registration name.", vbExclamation, "Warning")
            Exit Sub
        End If
        If TextBox2.Text = "SOFT" AndAlso TextBox3.Text = "GEEK" AndAlso TextBox4.Text = "YOUR" AndAlso TextBox5.Text = "LOVE" Then
            Dim strings As String = TextBox2.Text + "-" + TextBox3.Text + "-" + TextBox4.Text + "-" + TextBox5.Text
            Dim lines As String() = {TextBox1.Text, strings}
            File.WriteAllLines(filePath, lines)
            MessageBox.Show("Thank You !" & vbNewLine & "You have registered." & vbNewLine & "For questions and technical support?" & vbNewLine & "notesec@hotmail.com", "Registration Successful!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Application.Restart()
        ElseIf TextBox2.Text = "WINS" AndAlso TextBox3.Text = "OFTD" AndAlso TextBox4.Text = "EMOF" AndAlso TextBox5.Text = "ORAL" Then
            Dim strings As String = TextBox2.Text + "-" + TextBox3.Text + "-" + TextBox4.Text + "-" + TextBox5.Text
            Dim lines As String() = {TextBox1.Text, strings}
            File.WriteAllLines(filePath, lines)
            MessageBox.Show("Thank You !" & vbNewLine & "You have registered." & vbNewLine & "For questions and technical support?" & vbNewLine & "notesec@hotmail.com", "Registration Successful!", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Application.Restart()
        Else
            lbout.Text = TextBox2.Text.ToUpper & "-" & TextBox3.Text.ToUpper & "-" & TextBox4.Text.ToUpper & "-" & TextBox5.Text.ToUpper
            cekhash()
        End If

    End Sub

    Private Sub frmRegister_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        AddHandler TextBox2.KeyDown, AddressOf SerialTextBox_KeyDown
        AddHandler TextBox3.KeyDown, AddressOf SerialTextBox_KeyDown
        AddHandler TextBox4.KeyDown, AddressOf SerialTextBox_KeyDown
        AddHandler TextBox5.KeyDown, AddressOf SerialTextBox_KeyDown
    End Sub

    Private Sub TextBox2_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox2.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.V Then
            e.SuppressKeyPress = True
            PasteSerial()
        End If
    End Sub
    Private Sub SerialTextBox_KeyDown(ByVal sender As Object, ByVal e As KeyEventArgs) _
    Handles TextBox2.KeyDown, TextBox3.KeyDown, TextBox4.KeyDown, TextBox5.KeyDown

        Dim tb As TextBox = CType(sender, TextBox)

        ' BACKSPACE ditekan
        If e.KeyCode = Keys.Back Then

            ' Kalau textbox kosong → pindah ke sebelumnya
            If tb.SelectionStart = 0 AndAlso tb.TextLength = 0 Then
                e.SuppressKeyPress = True

                Select Case tb.Name
                    Case "TextBox5"
                        TextBox4.Focus()
                    Case "TextBox4"
                        TextBox3.Focus()
                    Case "TextBox3"
                        TextBox2.Focus()
                End Select
            End If

        End If

    End Sub

    Private Sub PasteSerial()
        If Not Clipboard.ContainsText() Then Exit Sub

        Dim raw As String = Clipboard.GetText().Trim()

        ' Hapus spasi, normalize
        raw = raw.Replace(" ", "").ToUpper()

        ' Pisah berdasarkan "-"
        Dim parts() As String = raw.Split("-"c)

        If parts.Length <> 4 Then
            MessageBox.Show("product Key Format is invalid", "Error",
                            MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If

        TextBox2.Text = parts(0).Substring(0, Math.Min(4, parts(0).Length))
        TextBox3.Text = parts(1).Substring(0, Math.Min(4, parts(1).Length))
        TextBox4.Text = parts(2).Substring(0, Math.Min(4, parts(2).Length))
        TextBox5.Text = parts(3).Substring(0, Math.Min(4, parts(3).Length))

        Button1.Focus()
    End Sub
    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        If Len(TextBox2.Text) >= TextBox2.MaxLength Then
            TextBox3.Focus()
        End If
    End Sub

    Private Sub TextBox3_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox3.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.V Then
            e.SuppressKeyPress = True
            PasteSerial()
        End If
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged
        If Len(TextBox3.Text) >= TextBox3.MaxLength Then
            TextBox4.Focus()
        End If
    End Sub

    Private Sub TextBox4_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox4.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.V Then
            e.SuppressKeyPress = True
            PasteSerial()
        End If
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged
        If Len(TextBox4.Text) >= TextBox4.MaxLength Then
            TextBox5.Focus()
        End If
    End Sub

    Private Sub TextBox5_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox5.KeyDown
        If e.Control AndAlso e.KeyCode = Keys.V Then
            e.SuppressKeyPress = True
            PasteSerial()
        End If
    End Sub

    Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox5.TextChanged
        If Len(TextBox5.Text) >= TextBox5.MaxLength Then
            Button1.Focus()
        End If
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Close()
        frmBuy.ShowDialog()
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        Me.Close()
    End Sub
End Class