﻿Imports System.Text.RegularExpressions
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging
Module ExtractImgRTF
    Public Function ExtractImagesFromRtf(ByVal rtf As String) As List(Of Image)
        Dim images As New List(Of Image)

        ' Regex untuk mencari block pict di RTF (\pict ... \pngblip atau \jpegblip)
        Dim pictRegex As New Regex("\\pict[^\n]+?\n([0-9a-fA-F\r\n]+)", RegexOptions.IgnoreCase)
        Dim matches As MatchCollection = pictRegex.Matches(rtf)

        For Each m As Match In matches
            Dim hexData As String = m.Groups(1).Value
            ' Hilangkan newline atau spasi
            hexData = Regex.Replace(hexData, "\s+", "")

            ' Convert hex ke byte array
            Dim bytes((hexData.Length \ 2) - 1) As Byte
            For i As Integer = 0 To bytes.Length - 1
                bytes(i) = Convert.ToByte(hexData.Substring(i * 2, 2), 16)
            Next

            ' Coba konversi ke Image
            Try
                Using ms As New MemoryStream(bytes)
                    images.Add(Image.FromStream(ms))
                End Using
            Catch ex As Exception
                ' Jika gagal konversi (OLE header), bisa dibuang atau diproses lagi
            End Try
        Next

        Return images
    End Function
End Module
