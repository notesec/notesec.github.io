﻿Public Class frmBuy

    Private Sub Label8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.ActiveControl = Nothing
        Process.Start("https://www.paypal.com/ncp/payment/BTX826ASTP8AN")
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.ActiveControl = Nothing
    End Sub

  
    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.ActiveControl = Nothing
        Process.Start("https://www.paypal.com/ncp/payment/XVVTHQQKEB5ZS")
    End Sub
End Class