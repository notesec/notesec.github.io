﻿Imports Microsoft.Win32
Imports System.Reflection
Imports System.IO
Imports System.Windows.Forms

Module ModuleFileAssociation

    Private Const EXTENSION As String = ".ns"
    Private Const PROG_ID As String = "Notesec.File"
    Private Const DESCRIPTION As String = "Notesec Secure Document"

    ' =========================
    ' ASSOCIATE .ns FILE
    ' =========================
    Public Sub AssociateNSFile()
        Try
            Dim exePath As String = Assembly.GetExecutingAssembly().Location

            ' .ns → ProgID
            Dim extKey As RegistryKey = Registry.ClassesRoot.CreateSubKey(EXTENSION)
            If extKey IsNot Nothing Then
                extKey.SetValue("", PROG_ID)
                extKey.Close()
            End If

            ' ProgID
            Dim progKey As RegistryKey = Registry.ClassesRoot.CreateSubKey(PROG_ID)
            If progKey IsNot Nothing Then
                progKey.SetValue("", DESCRIPTION)

                ' Default icon
                Dim iconKey As RegistryKey = progKey.CreateSubKey("DefaultIcon")
                If iconKey IsNot Nothing Then
                    iconKey.SetValue("", exePath & ",0")
                    iconKey.Close()
                End If

                ' Open command
                Dim cmdKey As RegistryKey = progKey.CreateSubKey("Shell\Open\Command")
                If cmdKey IsNot Nothing Then
                    cmdKey.SetValue("", """" & exePath & """ ""%1""")
                    cmdKey.Close()
                End If

                progKey.Close()
            End If

            NotifyShell()

        Catch ex As Exception
            MessageBox.Show("Failed to associate .ns file." & vbCrLf & ex.Message,
                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' =========================
    ' UNASSOCIATE .ns FILE
    ' =========================
    Public Sub UnassociateNSFile()
        Try
            Try
                Registry.ClassesRoot.DeleteSubKeyTree(EXTENSION)
            Catch
            End Try

            Try
                Registry.ClassesRoot.DeleteSubKeyTree(PROG_ID)
            Catch
            End Try
            NotifyShell()

        Catch ex As Exception
            MessageBox.Show("Failed to unassociate .ns file." & vbCrLf & ex.Message,
                            "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    ' =========================
    ' CHECK ASSOCIATION
    ' =========================
    Public Function IsNSAssociated() As Boolean
        Try
            Dim key As RegistryKey = Registry.ClassesRoot.OpenSubKey(EXTENSION)
            If key Is Nothing Then Return False

            Dim value As Object = key.GetValue("")
            key.Close()

            If value Is Nothing Then Return False
            Return value.ToString() = PROG_ID

        Catch
            Return False
        End Try
    End Function

    ' =========================
    ' REFRESH WINDOWS SHELL
    ' =========================
    Private Sub NotifyShell()
        SHChangeNotify(&H8000000, &H1000, IntPtr.Zero, IntPtr.Zero)
    End Sub

    Private Declare Auto Sub SHChangeNotify Lib "shell32.dll" ( _
        ByVal wEventId As Integer, _
        ByVal uFlags As Integer, _
        ByVal dwItem1 As IntPtr, _
        ByVal dwItem2 As IntPtr)

End Module
