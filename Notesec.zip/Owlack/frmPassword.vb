﻿Imports System.IO

Public Class frmPassword
    Public Property Password As String = ""
    Private filePath As String = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "data.reg")
    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        If RadioButton1.Checked Then
            TextBox1.Enabled = False
        Else
            TextBox1.Enabled = True
            TextBox1.Focus()
        End If
    End Sub
    Sub isreg()
        If File.Exists(filePath) Then

        Else
            RadioButton2.Checked = False
            RadioButton2.Text = "Enter Password (Unregistered)"
            RadioButton2.Enabled = False
            RadioButton1.Checked = True
            CheckBox1.Enabled = False
            TextBox1.Focus()
        End If
    End Sub
    Private Sub frmPassword_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        isreg()
        Me.TopMost = True
        TextBox1.Focus()
        If RadioButton2.Checked Then
            Label1.Visible = True
        Else
            Label1.Visible = False
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        If RadioButton1.Checked Then
            My.Settings.pass = ""
            My.Settings.Save()
            Password = GetHWID()
            Me.DialogResult = DialogResult.OK
            Me.Close()
        Else
            My.Settings.pass = "Custom"
            My.Settings.Save()
            If String.IsNullOrEmpty(TextBox1.Text) Then
                MsgBox("Password cannot be empty.", vbExclamation, "Error")
            Else
                Password = TextBox1.Text
                Me.DialogResult = DialogResult.OK
                Me.Close()
            End If
        End If

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.DialogResult = DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked Then
            TextBox1.UseSystemPasswordChar = False
        Else
            TextBox1.UseSystemPasswordChar = True
        End If
    End Sub

    Private Sub TextBox1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.GotFocus
        Label1.Visible = False
    End Sub

    Private Sub TextBox1_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles TextBox1.KeyPress
        If e.KeyChar = Chr(13) Then
            If RadioButton1.Checked Then
                Password = GetHWID()
                Me.DialogResult = DialogResult.OK
                Me.Close()
            Else
                If String.IsNullOrEmpty(TextBox1.Text) Then
                    MsgBox("Password cannot be empty.", vbExclamation, "Error")
                Else
                    Password = TextBox1.Text
                    Me.DialogResult = DialogResult.OK
                    Me.Close()
                End If
            End If
            e.Handled = True
        End If
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Label1.Visible = False
    End Sub

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        If RadioButton2.Checked Then
            TextBox1.Focus()
        End If
    End Sub

    Private Sub LinkLabel1_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles LinkLabel1.LinkClicked
        MsgBox("Your Default Password is <" & GetHWID() & ">.", vbExclamation)
    End Sub
End Class