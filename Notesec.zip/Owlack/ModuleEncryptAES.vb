﻿Imports System
Imports System.IO
Imports System.Security.Cryptography
Imports System.Text
Imports System.Threading
Imports System.Management
Module ModuleEncryptAES
    Public userpassword As String
    Public defaultpassword As String
    Public Delegate Sub ProgressCallback(ByVal percent As Integer)

    Private Const SecretKey As String = "Gamemetalslug@1"

    ' =========================
    ' ENCRYPT
    ' =========================
    Public Function EncryptText(ByVal plainText As String,
                                ByVal password As String,
                                Optional ByVal progress As ProgressCallback = Nothing) As String

        ' Validasi input (lebih manusiawi)
        If String.IsNullOrEmpty(plainText) Then
            Throw New ApplicationException("Data to be encrypted is still empty.")
        End If

        If String.IsNullOrEmpty(password) Then
            Throw New ApplicationException("Password is not filled in.")
        End If

        Try
            Dim bytes() As Byte = Encoding.UTF8.GetBytes(plainText)

            Dim key(31) As Byte, iv(15) As Byte
            GenerateKeyIV(password, key, iv)

            Using aes As New RijndaelManaged()
                aes.Key = key
                aes.IV = iv
                aes.Mode = CipherMode.CBC
                aes.Padding = PaddingMode.PKCS7

                Using ms As New MemoryStream()
                    Using cs As New CryptoStream(ms, aes.CreateEncryptor(), CryptoStreamMode.Write)

                        ProcessWithProgress(bytes, cs, progress)

                        cs.FlushFinalBlock()
                        Return Convert.ToBase64String(ms.ToArray())
                    End Using
                End Using
            End Using

        Catch ex As CryptographicException
            Throw New ApplicationException(
                "The encryption process failed. The password may be incorrect or the data may be invalid.", ex)

        Catch ex As Exception
            Throw New ApplicationException(
                "An error occurred while encrypting the data. Please try again.", ex)
        End Try

    End Function

    ' =========================
    ' DECRYPT
    ' =========================
    Public Function DecryptText(ByVal cipherText As String,
                                ByVal password As String,
                                Optional ByVal progress As ProgressCallback = Nothing) As String

        If String.IsNullOrEmpty(cipherText) Then
            Throw New ApplicationException("Encrypted data is still empty.")
        End If

        If String.IsNullOrEmpty(password) Then
            Throw New ApplicationException("Password not filled in.")
        End If

        Try
            Dim bytes() As Byte = Convert.FromBase64String(cipherText)

            Dim key(31) As Byte, iv(15) As Byte
            GenerateKeyIV(password, key, iv)

            Using aes As New RijndaelManaged()
                aes.Key = key
                aes.IV = iv
                aes.Mode = CipherMode.CBC
                aes.Padding = PaddingMode.PKCS7

                Using ms As New MemoryStream()
                    Using cs As New CryptoStream(ms, aes.CreateDecryptor(), CryptoStreamMode.Write)

                        ProcessWithProgress(bytes, cs, progress)

                        cs.FlushFinalBlock()
                        Return Encoding.UTF8.GetString(ms.ToArray())
                    End Using
                End Using
            End Using

        Catch ex As FormatException
            Throw New ApplicationException(
                "Invalid data format. Ensure the data entered is properly encrypted.", ex)

        Catch ex As CryptographicException
            Throw New ApplicationException(
                "Failed to open data. Incorrect password or corrupted data.", ex)

        Catch ex As Exception
            Throw New ApplicationException(
                "An error occurred while decrypting the data. Please try again.", ex)
        End Try

    End Function

    ' =========================
    ' PROSES DENGAN PROGRESS
    ' =========================
    Private Sub ProcessWithProgress(ByVal data() As Byte,
                                    ByVal cryptoStream As CryptoStream,
                                    ByVal progress As ProgressCallback)

        Dim blockSize As Integer = 4096
        Dim total As Integer = data.Length
        Dim processed As Integer = 0

        While processed < total
            Dim chunkSize As Integer = Math.Min(blockSize, total - processed)
            cryptoStream.Write(data, processed, chunkSize)
            processed += chunkSize

            If progress IsNot Nothing AndAlso total > 0 Then
                progress(CInt((processed * 100) / total))
            End If

            Thread.Sleep(1) ' opsional untuk UI
        End While
    End Sub

    ' =========================
    ' KEY & IV
    ' =========================
    Private Sub GenerateKeyIV(ByVal password As String,
                              ByRef key() As Byte,
                              ByRef iv() As Byte)

        Try
            Using sha As New SHA256Managed()
                Dim keyBytes() As Byte = sha.ComputeHash(Encoding.UTF8.GetBytes(password))
                Array.Copy(keyBytes, key, 32)
            End Using

            Using md5 As New MD5CryptoServiceProvider()
                Dim ivBytes() As Byte = md5.ComputeHash(Encoding.UTF8.GetBytes(password))
                Array.Copy(ivBytes, iv, 16)
            End Using

        Catch ex As Exception
            Throw New ApplicationException(
                "Failed to prepare encryption key. Password cannot be processed.", ex)
        End Try

    End Sub
    Public Function GetHWID_CPU() As String
        Try
            Dim searcher As New ManagementObjectSearcher("SELECT ProcessorId FROM Win32_Processor")
            For Each obj As ManagementObject In searcher.Get()
                If obj("ProcessorId") IsNot Nothing Then
                    Return obj("ProcessorId").ToString()
                End If
            Next
        Catch
        End Try
        Return "CPU_UNKNOWN"
    End Function
    Public Function GetHWID_MB() As String
        Try
            Dim searcher As New ManagementObjectSearcher("SELECT SerialNumber FROM Win32_BaseBoard")
            For Each obj As ManagementObject In searcher.Get()
                If obj("SerialNumber") IsNot Nothing Then
                    Return obj("SerialNumber").ToString()
                End If
            Next
        Catch
        End Try
        Return "MB_UNKNOWN"
    End Function
    Public Function GetHWID_HDD() As String
        Try
            Dim searcher As New ManagementObjectSearcher("SELECT SerialNumber FROM Win32_PhysicalMedia")
            For Each obj As ManagementObject In searcher.Get()
                If obj("SerialNumber") IsNot Nothing Then
                    Return obj("SerialNumber").ToString().Trim()
                End If
            Next
        Catch
        End Try
        Return "HDD_UNKNOWN"
    End Function
    Public Function GetHWID() As String
        Dim raw As String = _
            GetHWID_CPU() & _
            GetHWID_MB() & _
            GetHWID_HDD()

        Using md5 As MD5 = MD5.Create()
            Dim bytes() As Byte = Encoding.UTF8.GetBytes(raw)
            Dim hash() As Byte = md5.ComputeHash(bytes)

            Dim sb As New StringBuilder()
            For Each b As Byte In hash
                sb.Append(b.ToString("X2"))
            Next

            Return sb.ToString()
        End Using
    End Function
End Module
